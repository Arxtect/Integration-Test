A PDF containing the slides can be created using the following command: pdflatex presentation.tex

Alternatively, the LaTeX editor Texmaker can be used (http://www.xm1math.net/texmaker), which is available for Windows, OS X and Linux.

Make sure that your LaTeX distribution has been properly installed (e.g., TeX Live, MiKTeX).

