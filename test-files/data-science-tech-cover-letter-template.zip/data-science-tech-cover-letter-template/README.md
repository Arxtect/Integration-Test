# data-science-tech-cover-letter-template
## OFFICIAL PUBLIC OVERLEAF TEMPLATE
Link: https://www.overleaf.com/latex/templates/data-science-tech-cover-letter-template/gbrcqktbsfxf

Created to serve as form letter for creation of many letters, as a complement to data-science-tech-resume-template:
https://www.overleaf.com/latex/templates/data-science-tech-resume-template/zcdmpfxrzjhv

### Files:
- cover_letter.tex: Main file
- _header.tex: header code
- TLCcoverletter.sty: style file containing formatting details
- opening: why does comapny & role interest me?
- section/second: why am I an asset to the company?
- section/closing: seal the deal
- section/signoff: signature and stuff

### Editor:
https://github.com/TimmyChan 
https://www.linkedin.com/in/timmy-l-chan/
               
#### Last Updated: March 24th, 2022


